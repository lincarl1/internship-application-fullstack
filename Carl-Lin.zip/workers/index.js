var urls = []; //Array to keep track of the urls provided by the origin url
let originURL = 'https://cfw-takehome.developers.workers.dev/api/variants'; //URL that holds array of urls
let variantToReturn = Math.round(Math.random()); //Randomly Generates 0 or 1 - Signifies The Response
let response; //Variable to be returned by the event
let initialRequest; //Initial Fetch Request

const html1 = ` 
<html>
<head>
<title>Carl - Variant 1</title>
<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/@tailwindcss/ui@latest/dist/tailwind-ui.min.css"
/>
</head>
<body>
<div
  class="fixed bottom-0 inset-x-0 px-4 pb-6 sm:inset-0 sm:p-0 sm:flex sm:items-center sm:justify-center"
>
  <div class="fixed inset-0 transition-opacity">
    <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
  </div>

  <div
    class="bg-white rounded-lg px-4 pt-5 pb-4 overflow-hidden shadow-xl transform transition-all sm:max-w-sm sm:w-full sm:p-6"
  >
    <div>
      <div
        class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100"
      >
        <svg
          class="h-6 w-6 text-green-600"
          stroke="currentColor"
          fill="none"
          viewBox="0 0 24 24"
        >
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            stroke-width="2"
            d="M5 13l4 4L19 7"
          />
        </svg>
      </div>
      <div class="mt-3 text-center sm:mt-5">
        <h1 class="text-lg leading-6 font-medium text-gray-900" id="title">
          Thanks for Hosting!! - Carl
        </h1>
        <div class="mt-2">
          <p class="text-sm leading-5 text-gray-500" id="description">
            This is going to display my GitHub!
          </p>
        </div>
      </div>
    </div>
    <div class="mt-5 sm:mt-6">
      <span class="flex w-full rounded-md shadow-sm">
        <a
          class="inline-flex justify-center w-full rounded-md border border-transparent px-4 py-2 bg-indigo-600 text-base leading-6 font-medium text-white shadow-sm hover:bg-indigo-500 focus:outline-none focus:border-indigo-700 focus:shadow-outline-indigo transition ease-in-out duration-150 sm:text-sm sm:leading-5"
          href="https://github.com/lincarl1"
          id="url"
        >
          Navigate to Github
        </a>
      </span>
    </div>
  </div>
</div>
</body>
</html>`

const html2 = `
<html>
<head>
  <title>Carl - Variant 2</title>
  <link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/@tailwindcss/ui@latest/dist/tailwind-ui.min.css"
  />
</head>
<body>
  <div
    class="fixed bottom-0 inset-x-0 px-4 pb-6 sm:inset-0 sm:p-0 sm:flex sm:items-center sm:justify-center"
  >
    <div class="fixed inset-0 transition-opacity">
      <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
    </div>

    <div
      class="bg-white rounded-lg px-4 pt-5 pb-4 overflow-hidden shadow-xl transform transition-all sm:max-w-sm sm:w-full sm:p-6"
    >
      <div>
        <div
          class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100"
        >
          <svg
            class="h-6 w-6 text-green-600"
            stroke="currentColor"
            fill="none"
            viewBox="0 0 24 24"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M5 13l4 4L19 7"
            />
          </svg>
        </div>
        <div class="mt-3 text-center sm:mt-5">
          <h1 class="text-lg leading-6 font-medium text-gray-900" id="title">
            Thanks for Hosting!! - Carl
          </h1>
          <div class="mt-2">
            <p class="text-sm leading-5 text-gray-500" id="description">
              The following is a link to my LinkedIn page!
            </p>
          </div>
        </div>
      </div>
      <div class="mt-5 sm:mt-6">
        <span class="flex w-full rounded-md shadow-sm">
          <a
            class="inline-flex justify-center w-full rounded-md border border-transparent px-4 py-2 bg-green-600 text-base leading-6 font-medium text-white shadow-sm hover:bg-green-500 focus:outline-none focus:border-green-700 focus:shadow-outline-indigo transition ease-in-out duration-150 sm:text-sm sm:leading-5"
            href="https://www.linkedin.com/in/lincarl1/"
            id="url"
          >
            Route To LinkedIn Page
          </a>
        </span>
      </div>
    </div>
  </div>
</body>
</html>`

// class AttributeRewriter {
//   constructor(attributeName) {
//     this.attributeName = attributeName;
//   }
  
//   element(e)
//   {
//     console.log(element.e);
//     console.log(e);
//   }

//   text(text)
//   {
//     if(this.textChunk === null)
//     {
//       this.textChunk = text.text;
//     }
//     else
//     {
//       this.textChunk += text.text;
//     }

//     console.log(text.text);


//       if(this.text.includes('<title>Variant 1</title>'))
//       {
//         try {
//           console.log("True");
//           text.replace(text.text.replace('<title>Variant 1</title>', '<title>Carl</title>'));
//         } catch (error) {
//           console.log(error);
//         }
//       }


//     console.log(text);
//     text.replace(text.text.replace('title', 'Carl'));
//     text.replace(text.text.replace('h1[id="title"]', 'Thanks for Hosting!!'));
//     text.replace(text.text.replace('p#desrcription', 'Visit My LinkedIn Here!'));
//     text.replace(text.text.replace('https://cloudflare.com', 'https://www.linkedin.com/in/lincarl1/'))
//   }

// }

// const rewriter = new HTMLRewriter()
//   .on('title', new AttributeRewriter('Carl'))
//   .on('h1[id="title"]', new AttributeRewriter('Thanks for Hosting!!'))
//   .on('p[id="description"]', new AttributeRewriter('Visit My LinkedIn Here!'))
//   .on('a[id="url"]', new AttributeRewriter('https://www.linkedin.com/in/lincarl1/'))

addEventListener('fetch', event => {
  event.respondWith(handleRequest(originURL))
})
/**
 * Respond with hello worker text
 * @param {Request} request
 */
async function handleRequest(request) {

  initialRequest = await fetch(request);

  if(initialRequest.ok)
  {
    let variantFile = await initialRequest.json();
    for (var i = 0; i < variantFile.variants.length; i++)
    {
      urls.push(variantFile.variants[i]);
    }
  }
  else
  {
    console.error('Failed to Find Request')
  }


  //Returns Body
  response = (await fetch(urls[variantToReturn])).body;

  if(variantToReturn == 0)
  {
    return new Response(html1, {
    headers: {'content-type': 'text/html'}, })
  }
  else
  {
    return new Response(html2, {
    headers: {'content-type': 'text/html'}, })
  }

  // return new Response(response, {
  //   headers: {'content-type': 'text/html'}, })
} 
